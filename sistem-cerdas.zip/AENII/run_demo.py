"""
Demo Script untuk Sistem Cerdas Rekomendasi Menu Diet
Script ini menjalankan demo otomatis tanpa input manual
"""

from diet_system import DietSystem
from rules import DietRules
from utils import calculate_bmi

def run_demo():
    """Menjalankan demo dengan 3 contoh kasus"""
    
    print("🎭 DEMO SISTEM CERDAS REKOMENDASI MENU DIET")
    print("=" * 60)
    print("Demo ini menunjukkan 3 kasus berbeda:")
    print("1. Turun Berat Badan")
    print("2. Naik Berat Badan") 
    print("3. Menjaga Berat Badan")
    print("=" * 60)
    
    # Data demo
    demo_cases = [
        {
            'name': 'Andi - Ingin Turun Berat Badan',
            'age': 25,
            'weight': 80,
            'height': 170,
            'activity': 'normal',
            'goal': 'turun',
            'description': 'Pria 25 tahun, overweight, ingin diet'
        },
        {
            'name': 'Sari - Ingin Naik Berat Badan',
            'age': 22,
            'weight': 45,
            'height': 160,
            'activity': 'ringan',
            'goal': 'naik',
            'description': 'Wanita 22 tahun, underweight, ingin menambah BB'
        },
        {
            'name': 'Budi - Menjaga Berat Badan',
            'age': 30,
            'weight': 70,
            'height': 175,
            'activity': 'berat',
            'goal': 'stabil',
            'description': 'Pria 30 tahun, normal weight, maintenance'
        }
    ]
    
    # Inisialisasi sistem
    diet_system = DietSystem()
    diet_rules = DietRules()
    
    for i, case in enumerate(demo_cases, 1):
        print(f"\n{'='*60}")
        print(f"📋 DEMO KASUS {i}: {case['name']}")
        print(f"📝 Deskripsi: {case['description']}")
        print("="*60)
        
        # Input data
        print(f"👤 Profil:")
        print(f"   Umur: {case['age']} tahun")
        print(f"   Berat: {case['weight']} kg")
        print(f"   Tinggi: {case['height']} cm")
        print(f"   Aktivitas: {case['activity'].title()}")
        print(f"   Tujuan: {case['goal'].title()} berat badan")
        
        # Proses data
        user_profile = diet_system.process_user_input(
            case['age'], case['weight'], case['height'],
            case['activity'], case['goal']
        )
        
        # Hitung BMI
        bmi_value, bmi_category = calculate_bmi(case['weight'], case['height'])
        
        # Terapkan rules
        results = diet_rules.apply_rules(user_profile)
        
        # Tampilkan hasil
        print(f"\n🔥 Hasil Perhitungan:")
        print(f"   BMR: {user_profile['bmr']} kalori/hari")
        print(f"   Kebutuhan Kalori: {user_profile['daily_calories']} kalori/hari")
        print(f"   Target Kalori: {user_profile['target_calories']} kalori/hari")
        print(f"   BMI: {bmi_value} ({bmi_category})")
        print(f"   Kategori Diet: {user_profile['diet_category']}")
        
        print(f"\n🍽️ Rekomendasi Menu:")
        print(f"   Fokus: {results['diet_focus']}")
        print(f"   Tips: {results['diet_tips']}")
        
        menu = results['menu_recommendation']
        print(f"\n   🌅 Sarapan: {menu['sarapan'][0]}")
        print(f"   🌞 Siang: {menu['siang'][0]}")
        print(f"   🌙 Malam: {menu['malam'][0]}")
        print(f"   🍎 Snack: {menu['snack'][0]}")
        
        if i < len(demo_cases):
            input(f"\n⏳ Tekan Enter untuk melihat demo kasus {i+1}...")
    
    print(f"\n{'='*60}")
    print("✅ DEMO SELESAI!")
    print("💡 Ini menunjukkan bagaimana rule-based system bekerja")
    print("🎯 Setiap tujuan diet menghasilkan rekomendasi yang berbeda")
    print("📊 Perhitungan BMR dan kalori disesuaikan dengan profil")
    print("🍽️ Menu dipilih berdasarkan rules yang telah ditetapkan")
    print("="*60)

def show_rules_explanation():
    """Menampilkan penjelasan rules yang digunakan"""
    
    print("\n🧠 PENJELASAN RULE-BASED SYSTEM")
    print("="*60)
    
    print("\n📐 Rules Perhitungan:")
    print("1. BMR = 66 + (13.7 × berat) + (5 × tinggi) – (6.8 × umur)")
    print("2. Kalori Harian = BMR × Faktor Aktivitas")
    print("   - Ringan: × 1.2")
    print("   - Normal: × 1.35") 
    print("   - Berat: × 1.5")
    print("3. Target Kalori:")
    print("   - Turun BB: Kalori Harian - 300")
    print("   - Stabil: Kalori Harian")
    print("   - Naik BB: Kalori Harian + 300")
    
    print("\n🍽️ Rules Menu:")
    print("1. Turun BB → Menu rendah kalori, tinggi protein, banyak sayur")
    print("2. Stabil → Menu seimbang dengan porsi normal")
    print("3. Naik BB → Menu tinggi kalori, protein, dan karbohidrat")
    
    print("\n✅ Keunggulan Rule-Based System:")
    print("• Transparan - setiap keputusan dapat dijelaskan")
    print("• Konsisten - hasil sama untuk input yang sama")
    print("• Mudah dimodifikasi - rules dapat diubah kapan saja")
    print("• Cepat - tidak perlu training seperti ML")

if __name__ == "__main__":
    print("🚀 Memulai Demo Sistem Diet...")
    
    try:
        # Jalankan demo
        run_demo()
        
        # Tanya apakah ingin melihat penjelasan rules
        show_rules = input("\n🤔 Ingin melihat penjelasan rules? (y/n): ")
        if show_rules.lower() in ['y', 'yes', 'ya']:
            show_rules_explanation()
        
        print("\n👋 Terima kasih telah melihat demo!")
        print("💻 Untuk penggunaan normal, jalankan: python main.py")
        
    except KeyboardInterrupt:
        print("\n\n⚠️ Demo dihentikan oleh pengguna.")
    except Exception as e:
        print(f"\n❌ Error dalam demo: {str(e)}")
        print("🔧 Silakan periksa kode atau hubungi developer.")