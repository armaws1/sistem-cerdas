"""
Sistem Cerdas Rekomendasi Menu Diet
Core Logic untuk perhitungan BMR, kalori, dan kategori diet
"""

class DietSystem:
    def __init__(self):
        """Inisialisasi sistem diet"""
        self.user_data = {}
        self.bmr = 0
        self.daily_calories = 0
        self.target_calories = 0
        self.diet_category = ""
    
    def input_user_data(self, age, weight, height, activity_level, diet_goal):
        """
        Menyimpan data pengguna
        
        Args:
            age (int): Umur pengguna
            weight (float): Berat badan dalam kg
            height (float): Tinggi badan dalam cm
            activity_level (str): Level aktivitas (ringan/normal/berat)
            diet_goal (str): Tujuan diet (turun/stabil/naik)
        """
        self.user_data = {
            'age': age,
            'weight': weight,
            'height': height,
            'activity_level': activity_level.lower(),
            'diet_goal': diet_goal.lower()
        }
    
    def calculate_bmr(self):
        """
        Menghitung BMR menggunakan rumus Harris-Benedict (untuk pria)
        BMR = 66 + (13.7 × berat) + (5 × tinggi) – (6.8 × umur)
        
        Returns:
            float: Nilai BMR
        """
        weight = self.user_data['weight']
        height = self.user_data['height']
        age = self.user_data['age']
        
        self.bmr = 66 + (13.7 * weight) + (5 * height) - (6.8 * age)
        return self.bmr
    
    def calculate_daily_calories(self):
        """
        Menghitung kebutuhan kalori harian berdasarkan aktivitas
        
        Returns:
            float: Kebutuhan kalori harian
        """
        activity_multiplier = {
            'ringan': 1.2,
            'normal': 1.35,
            'berat': 1.5
        }
        
        multiplier = activity_multiplier.get(self.user_data['activity_level'], 1.35)
        self.daily_calories = self.bmr * multiplier
        return self.daily_calories
    
    def determine_target_calories(self):
        """
        Menentukan target kalori berdasarkan tujuan diet
        
        Returns:
            float: Target kalori sesuai tujuan
        """
        goal = self.user_data['diet_goal']
        
        if goal == 'turun':
            self.target_calories = self.daily_calories - 300
            self.diet_category = "Defisit Kalori (Turun Berat Badan)"
        elif goal == 'stabil':
            self.target_calories = self.daily_calories
            self.diet_category = "Maintenance (Menjaga Berat Badan)"
        elif goal == 'naik':
            self.target_calories = self.daily_calories + 300
            self.diet_category = "Surplus Kalori (Naik Berat Badan)"
        else:
            self.target_calories = self.daily_calories
            self.diet_category = "Maintenance (Default)"
        
        return self.target_calories
    
    def get_user_profile(self):
        """
        Mendapatkan profil lengkap pengguna
        
        Returns:
            dict: Data profil pengguna
        """
        return {
            'user_data': self.user_data,
            'bmr': round(self.bmr, 2),
            'daily_calories': round(self.daily_calories, 2),
            'target_calories': round(self.target_calories, 2),
            'diet_category': self.diet_category
        }
    
    def process_user_input(self, age, weight, height, activity_level, diet_goal):
        """
        Memproses semua input pengguna dan menghitung semua nilai
        
        Args:
            age (int): Umur pengguna
            weight (float): Berat badan
            height (float): Tinggi badan
            activity_level (str): Level aktivitas
            diet_goal (str): Tujuan diet
            
        Returns:
            dict: Profil lengkap hasil perhitungan
        """
        # Step 1: Input data pengguna
        self.input_user_data(age, weight, height, activity_level, diet_goal)
        
        # Step 2: Hitung BMR
        self.calculate_bmr()
        
        # Step 3: Hitung kalori harian berdasarkan aktivitas
        self.calculate_daily_calories()
        
        # Step 4: Tentukan target kalori berdasarkan tujuan
        self.determine_target_calories()
        
        # Step 5: Return profil lengkap
        return self.get_user_profile()