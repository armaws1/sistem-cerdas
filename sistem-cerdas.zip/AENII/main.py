"""
Main Application - Sistem Cerdas Rekomendasi Menu Diet
File utama untuk menjalankan aplikasi
"""

from diet_system import DietSystem
from rules import DietRules
from utils import get_user_input, display_results, save_results_to_file, calculate_bmi

def main():
    """
    Fungsi utama aplikasi
    Mengintegrasikan semua komponen sistem diet
    """
    try:
        # Step 1: Inisialisasi sistem
        print("🚀 Memulai Sistem Cerdas Rekomendasi Menu Diet...")
        diet_system = DietSystem()
        diet_rules = DietRules()
        
        # Step 2: Input data pengguna
        age, weight, height, activity_level, diet_goal = get_user_input()
        
        # Step 3: Proses data pengguna menggunakan DietSystem
        print("\n⚙️  Memproses data Anda...")
        user_profile = diet_system.process_user_input(
            age, weight, height, activity_level, diet_goal
        )
        
        # Step 4: Hitung BMI sebagai informasi tambahan
        bmi_value, bmi_category = calculate_bmi(weight, height)
        user_profile['bmi'] = bmi_value
        user_profile['bmi_category'] = bmi_category
        
        # Step 5: Terapkan rules untuk mendapatkan rekomendasi menu
        print("🧠 Menerapkan rule-based system...")
        results = diet_rules.apply_rules(user_profile)
        
        # Step 6: Tampilkan hasil
        display_results(results)
        
        # Step 7: Tampilkan informasi BMI
        print(f"\n📊 Informasi BMI Anda: {bmi_value} ({bmi_category})")
        
        # Step 8: Tanya apakah ingin menyimpan hasil
        save_choice = input("\n💾 Apakah Anda ingin menyimpan hasil ke file? (y/n): ")
        if save_choice.lower() in ['y', 'yes', 'ya']:
            filename = input("📝 Masukkan nama file (atau tekan Enter untuk default): ").strip()
            if not filename:
                filename = "diet_result.txt"
            elif not filename.endswith('.txt'):
                filename += '.txt'
            
            save_results_to_file(results, filename)
        
        # Step 9: Tanya apakah ingin menjalankan lagi
        print("\n" + "=" * 60)
        restart = input("🔄 Apakah Anda ingin menjalankan sistem lagi? (y/n): ")
        if restart.lower() in ['y', 'yes', 'ya']:
            print("\n" * 2)  # Clear screen effect
            main()  # Recursive call untuk restart
        else:
            print("\n👋 Terima kasih telah menggunakan Sistem Diet!")
            print("💪 Semoga berhasil mencapai tujuan diet Anda!")
            
    except KeyboardInterrupt:
        print("\n\n⚠️  Program dihentikan oleh pengguna.")
        print("👋 Terima kasih!")
    except Exception as e:
        print(f"\n❌ Terjadi error: {str(e)}")
        print("🔧 Silakan coba lagi atau hubungi developer.")

def demo_mode():
    """
    Mode demo dengan data contoh
    Untuk testing dan presentasi
    """
    print("🎭 DEMO MODE - Sistem Cerdas Rekomendasi Menu Diet")
    print("=" * 60)
    
    # Data contoh
    demo_data = [
        {
            'name': 'Andi (Turun BB)',
            'age': 25,
            'weight': 80,
            'height': 170,
            'activity': 'normal',
            'goal': 'turun'
        },
        {
            'name': 'Sari (Naik BB)',
            'age': 22,
            'weight': 45,
            'height': 160,
            'activity': 'ringan',
            'goal': 'naik'
        },
        {
            'name': 'Budi (Stabil)',
            'age': 30,
            'weight': 70,
            'height': 175,
            'activity': 'berat',
            'goal': 'stabil'
        }
    ]
    
    diet_system = DietSystem()
    diet_rules = DietRules()
    
    for i, data in enumerate(demo_data, 1):
        print(f"\n📋 Contoh {i}: {data['name']}")
        print("-" * 40)
        
        # Proses data
        user_profile = diet_system.process_user_input(
            data['age'], data['weight'], data['height'], 
            data['activity'], data['goal']
        )
        
        # Terapkan rules
        results = diet_rules.apply_rules(user_profile)
        
        # Tampilkan ringkasan
        profile = results['user_profile']
        print(f"BMR: {profile['bmr']} kalori")
        print(f"Target: {profile['target_calories']} kalori")
        print(f"Kategori: {profile['diet_category']}")
        print(f"Contoh Sarapan: {results['menu_recommendation']['sarapan'][0]}")
        
        if i < len(demo_data):
            input("\nTekan Enter untuk contoh berikutnya...")

if __name__ == "__main__":
    print("🍎 Selamat datang di Sistem Cerdas Rekomendasi Menu Diet!")
    print("\nPilih mode:")
    print("1. Mode Normal")
    print("2. Mode Demo")
    
    try:
        choice = input("\nPilihan Anda (1/2): ").strip()
        
        if choice == "2":
            demo_mode()
        else:
            main()
            
    except KeyboardInterrupt:
        print("\n\n👋 Terima kasih!")
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        print("Menjalankan mode normal...")
        main()