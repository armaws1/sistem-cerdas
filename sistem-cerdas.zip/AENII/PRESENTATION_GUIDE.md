# 🎯 PANDUAN PRESENTASI SISTEM DIET CERDAS

## 🚀 **STRUKTUR PRESENTASI (15-20 MENIT)**

### **1. OPENING (2 menit)**
```
🎬 "Selamat pagi/siang, hari ini saya akan mempresentasikan 
Sistem Cerdas Rekomendasi Menu Diet Berdasarkan Profil Pengguna 
menggunakan Rule-Based System"

💡 "Siapa di sini yang pernah bingung mau diet tapi ga tau harus makan apa?"
```

### **2. PROBLEM STATEMENT (2 menit)**
```
❌ Masalah yang ada:
- Banyak orang bingung menentukan menu diet yang tepat
- Aplikasi diet kebanyakan pakai Machine Learning yang "black box"
- Susah dijelaskan kenapa dapat rekomendasi tertentu
- Tidak personal sesuai profil individu

✅ Solusi kita:
- Rule-Based System yang transparan
- Rekomendasi personal berdasarkan profil
- Setiap keputusan bisa dijelaskan
- Mudah digunakan dan dipahami
```

### **3. DEMO LANGSUNG (8 menit)**
**Ini bagian paling penting! Buka `web_version.html`**

#### **Demo Case 1: Input Manual (3 menit)**
```
🎭 "Mari kita coba dengan profil saya sendiri..."

Input contoh:
- Umur: 22 tahun
- Berat: 65 kg  
- Tinggi: 170 cm
- Aktivitas: Normal
- Tujuan: Turun berat badan

🔥 Tunjukkan hasil:
- BMR: 1670.5 kalori
- Target: 1931 kalori (defisit 300)
- Menu: Oatmeal, nasi merah, sup sayur
```

#### **Demo Case 2: Demo Otomatis (5 menit)**
```
🎬 "Sekarang mari lihat 3 contoh kasus berbeda..."

Klik tombol "Jalankan Demo":

1. Andi (Turun BB): 
   - Overweight → Menu rendah kalori
   - Fokus: protein tinggi, sayur banyak

2. Sari (Naik BB):
   - Underweight → Menu tinggi kalori  
   - Fokus: protein + karbohidrat

3. Budi (Stabil):
   - Normal → Menu seimbang
   - Fokus: maintenance balance
```

### **4. TECHNICAL EXPLANATION (5 menit)**

#### **Rule-Based System (2 menit)**
```
🧠 "Kenapa Rule-Based, bukan Machine Learning?"

✅ Keunggulan:
- Transparan: setiap keputusan bisa dijelaskan
- Konsisten: input sama = output sama
- Mudah dimodifikasi: tinggal ubah rules
- Cepat: tidak perlu training data

📐 Rumus yang digunakan:
- BMR = 66 + (13.7×berat) + (5×tinggi) - (6.8×umur)
- Kalori = BMR × faktor aktivitas (1.2/1.35/1.5)
- Target = Kalori ± 300 (sesuai tujuan)
```

#### **Rules Logic (3 menit)**
```
🔧 "Bagaimana sistem memutuskan menu?"

IF tujuan = "turun" THEN
   - Menu rendah kalori
   - Tinggi protein (telur, ayam kukus)
   - Banyak sayur (brokoli, bayam)
   - Hindari gorengan

IF tujuan = "naik" THEN  
   - Menu tinggi kalori
   - Protein + karbohidrat (nasi + daging)
   - Lemak sehat (susu full cream)
   - Porsi lebih besar

IF tujuan = "stabil" THEN
   - Menu seimbang
   - Variasi nutrisi
   - Porsi normal
```

### **5. IMPLEMENTASI & FITUR (2 menit)**
```
💻 "Project ini diimplementasikan dalam 2 versi:"

🐍 Python Version:
- 4 file modular (main, diet_system, rules, utils)
- Object-oriented design
- Comprehensive testing

🌐 Web Version:
- HTML + JavaScript
- Responsive design  
- Real-time calculation
- No installation needed

📊 Fitur lengkap:
- Input validation
- BMI calculation
- 4 waktu makan (sarapan, siang, malam, snack)
- Tips diet personal
```

### **6. CLOSING & Q&A (1 menit)**
```
✅ "Kesimpulan:"
- Rule-Based System terbukti efektif untuk rekomendasi diet
- Transparan dan mudah dipahami
- Personal sesuai profil pengguna
- Siap digunakan untuk implementasi nyata

❓ "Ada pertanyaan?"
```

---

## 🎭 **TIPS PRESENTASI YANG BIKIN IMPRESSIVE**

### **1. Persiapan Teknis**
```
✅ Checklist sebelum presentasi:
□ Buka web_version.html di browser
□ Test semua fitur (input manual + demo)
□ Siapkan backup: buka Python version juga
□ Screenshot hasil untuk backup
□ Pastikan laptop/proyektor connect
```

### **2. Storytelling Approach**
```
🎬 Mulai dengan cerita:
"Kemarin teman saya bilang, 'Gue mau diet tapi bingung makan apa. 
Aplikasi A bilang makan ini, aplikasi B bilang makan itu. 
Kenapa beda-beda? Mana yang bener?'

Nah, dari situ saya kepikiran bikin sistem yang bisa 
MENJELASKAN kenapa kasih rekomendasi tertentu..."
```

### **3. Interactive Demo**
```
🎯 Libatkan audience:
"Siapa yang mau jadi volunteer? 
Kita input profil kamu dan lihat rekomendasinya!"

Atau:
"Coba tebak, kalau orang tinggi 160cm berat 45kg, 
sistemnya bakal rekomendasiin menu apa?"
```

### **4. Highlight Keunggulan**
```
💡 Tekankan poin ini:

🔍 "Lihat, setiap rekomendasi ada alasannya:
- Oatmeal → rendah kalori tapi mengenyangkan
- Nasi merah → karbohidrat kompleks, lebih sehat
- Ayam kukus → protein tinggi tanpa lemak berlebih"

🧠 "Ini bedanya dengan AI black box. 
Kita tau PERSIS kenapa sistem kasih rekomendasi ini!"
```

---

## 🎯 **SKENARIO DEMO STEP-BY-STEP**

### **Demo Scenario 1: Manual Input**
```
🎬 "Mari kita coba dengan profil nyata..."

Step 1: Buka web_version.html
"Ini adalah interface sistem kita. Clean, simple, user-friendly."

Step 2: Input data
"Saya input profil seseorang:
- Umur: 25 tahun
- Berat: 80 kg (sedikit overweight)  
- Tinggi: 170 cm
- Aktivitas: Normal (olahraga 2x seminggu)
- Tujuan: Turun berat badan"

Step 3: Klik Analisis
"Sistem langsung bekerja... dan voila!"

Step 4: Explain Results
"Lihat hasilnya:
- BMR 1801 kalori (metabolisme dasar)
- Kebutuhan 2431 kalori (dengan aktivitas)
- Target 2131 kalori (defisit 300 untuk turun BB)
- BMI 27.68 (Overweight) - konfirmasi perlu turun BB"

Step 5: Explain Menu
"Menu yang direkomendasikan:
- Sarapan: Oatmeal + pisang + telur → rendah kalori, protein tinggi
- Siang: Nasi merah + ayam kukus → karbohidrat kompleks, protein tanpa lemak
- Malam: Sup sayur + ikan → ringan tapi bergizi
- Snack: Yogurt → probiotik, rendah kalori"
```

### **Demo Scenario 2: Auto Demo**
```
🎬 "Sekarang mari lihat 3 kasus berbeda sekaligus..."

Klik "Jalankan Demo"

"Perhatikan bagaimana sistem memberikan rekomendasi berbeda:

1. Andi (Overweight):
   - Target defisit kalori
   - Menu fokus sayur + protein tanpa lemak
   
2. Sari (Underweight):  
   - Target surplus kalori
   - Menu tinggi protein + karbohidrat + lemak sehat
   
3. Budi (Normal):
   - Target maintenance
   - Menu seimbang dengan variasi

Ini menunjukkan sistem benar-benar personal!"
```

---

## 🔥 **JAWABAN UNTUK PERTANYAAN YANG MUNGKIN MUNCUL**

### **Q: "Kenapa tidak pakai Machine Learning?"**
```
A: "Bagus pertanyaannya! 

Rule-Based System lebih cocok untuk kasus ini karena:
1. Transparan - kita bisa jelaskan setiap keputusan
2. Tidak perlu data training yang besar
3. Mudah divalidasi oleh ahli gizi
4. Konsisten dan predictable
5. Mudah di-maintain dan update

ML bagus untuk pattern recognition, tapi untuk rekomendasi 
yang perlu dijelaskan ke user, Rule-Based lebih tepat."
```

### **Q: "Bagaimana validasi medisnya?"**
```
A: "Excellent point!

Rumus BMR yang kita pakai adalah Harris-Benedict Formula 
yang sudah divalidasi secara medis dan digunakan luas 
di dunia kesehatan.

Rules menu dikembangkan berdasarkan prinsip gizi seimbang:
- Defisit kalori untuk turun BB
- Surplus kalori untuk naik BB  
- Balance nutrisi untuk maintenance

Tentu saja, untuk implementasi nyata perlu konsultasi 
dengan ahli gizi untuk fine-tuning rules."
```

### **Q: "Bisa dikembangkan lebih lanjut?"**
```
A: "Absolutely! 

Pengembangan selanjutnya bisa:
1. Database menu yang lebih lengkap
2. Perhitungan nutrisi detail (protein, lemak, vitamin)
3. Integration dengan fitness tracker
4. Personalisasi berdasarkan preferensi makanan
5. Mobile app dengan notification
6. AI untuk optimasi rules berdasarkan feedback user

Foundation Rule-Based yang kuat memudahkan pengembangan ini."
```

---

## 🎯 **BACKUP PLAN JIKA ADA MASALAH TEKNIS**

### **Plan A: Web Version Bermasalah**
```
🔄 "Tidak masalah, kita punya backup Python version"
→ Buka terminal: py main.py
→ Demo dengan command line interface
```

### **Plan B: Laptop Bermasalah**  
```
📱 "Saya sudah siapkan screenshot hasil demo"
→ Tunjukkan gambar hasil
→ Explain step by step dari screenshot
```

### **Plan C: No Computer Access**
```
📝 "Mari kita walkthrough manual"
→ Tulis di whiteboard: rumus BMR
→ Hitung manual dengan contoh
→ Explain rules logic secara verbal
```

---

## 🏆 **CLOSING YANG POWERFUL**

```
🎯 "Jadi, apa yang membuat sistem ini special?

1. TRANSPARAN - Setiap rekomendasi ada alasan jelasnya
2. PERSONAL - Disesuaikan dengan profil masing-masing  
3. PRACTICAL - Langsung bisa dipakai, no complex setup
4. SCALABLE - Mudah dikembangkan dan di-improve

Sistem ini membuktikan bahwa tidak semua masalah perlu 
AI yang kompleks. Sometimes, the best solution is the 
simplest one that works.

Terima kasih. Ada pertanyaan?"

🎤 *Drop mic* 😎
```

---

## 📋 **CHECKLIST FINAL**

```
□ File web_version.html ready
□ Python backup ready (py main.py)
□ Demo scenarios practiced
□ Q&A answers prepared  
□ Laptop charged & tested
□ Backup screenshots ready
□ Confident & ready to rock! 🚀
```

**Good luck bro! You got this! 💪🔥**