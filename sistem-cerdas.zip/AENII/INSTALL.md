# Panduan Instalasi dan Penggunaan

## 📋 Persyaratan Sistem

### Minimum Requirements
- **Python**: 3.6 atau lebih baru
- **Operating System**: Windows, macOS, atau Linux
- **Memory**: 50 MB RAM
- **Storage**: 10 MB ruang kosong

### Recommended Requirements
- **Python**: 3.8 atau lebih baru
- **Terminal/Command Prompt**: Untuk menjalankan aplikasi

## 🚀 Cara Instalasi

### 1. Install Python (jika belum ada)

#### Windows:
1. Download Python dari [python.org](https://python.org)
2. Jalankan installer
3. ✅ Centang "Add Python to PATH"
4. Klik "Install Now"

#### macOS:
```bash
# Menggunakan Homebrew
brew install python3

# Atau download dari python.org
```

#### Linux (Ubuntu/Debian):
```bash
sudo apt update
sudo apt install python3 python3-pip
```

### 2. Verifikasi Instalasi Python
```bash
python --version
# atau
python3 --version
```

### 3. Download Project
1. Download semua file project
2. Ekstrak ke folder yang diinginkan
3. Buka terminal/command prompt
4. Navigate ke folder project

## 🎯 Cara Menjalankan

### 1. Mode Normal (Interactive)
```bash
python main.py
```

### 2. Mode Demo (Otomatis)
```bash
python run_demo.py
```

### 3. Test System (Verifikasi)
```bash
python test_system.py
```

## 📁 Struktur File Project

```
diet-recommendation-system/
├── main.py                 # File utama aplikasi
├── diet_system.py         # Core logic sistem
├── rules.py              # Rule-based system
├── utils.py              # Utility functions
├── run_demo.py           # Demo otomatis
├── test_system.py        # Testing script
├── README.md             # Dokumentasi utama
├── DOCUMENTATION.md      # Dokumentasi detail
├── INSTALL.md           # Panduan instalasi (file ini)
├── flowchart.md         # Flowchart sistem
├── requirements.txt     # Dependencies (kosong)
└── examples/
    └── sample_output.txt # Contoh output
```

## 🔧 Troubleshooting

### Problem: "Python was not found"
**Solution:**
1. Install Python dari python.org
2. Pastikan Python ditambahkan ke PATH
3. Restart terminal/command prompt
4. Coba `python3` jika `python` tidak bekerja

### Problem: "No module named 'xxx'"
**Solution:**
Project ini tidak memerlukan module eksternal. Semua menggunakan Python standard library.

### Problem: "Permission denied"
**Solution:**
```bash
# Linux/macOS
chmod +x *.py

# Windows: Run as Administrator
```

### Problem: File tidak ditemukan
**Solution:**
1. Pastikan semua file project ada di folder yang sama
2. Jalankan dari folder yang benar
3. Periksa nama file (case-sensitive di Linux/macOS)

## 📱 Penggunaan Aplikasi

### Input yang Diperlukan:
1. **Umur**: 10-100 tahun
2. **Berat Badan**: 30-200 kg
3. **Tinggi Badan**: 100-250 cm
4. **Aktivitas**: 
   - 1 = Ringan (jarang olahraga)
   - 2 = Normal (1-3x seminggu)
   - 3 = Berat (4-7x seminggu)
5. **Tujuan Diet**:
   - 1 = Turun berat badan
   - 2 = Menjaga berat badan
   - 3 = Naik berat badan

### Output yang Dihasilkan:
- Profil pengguna
- BMR (Basal Metabolic Rate)
- Kebutuhan kalori harian
- Target kalori sesuai tujuan
- BMI dan kategori
- Rekomendasi menu lengkap
- Tips diet

## 🎭 Mode Demo

Mode demo menampilkan 3 contoh kasus:
1. **Andi** - Turun berat badan (Overweight)
2. **Sari** - Naik berat badan (Underweight)  
3. **Budi** - Menjaga berat badan (Normal)

## 🧪 Testing

Jalankan test untuk memverifikasi sistem:
```bash
python test_system.py
```

Test yang dilakukan:
- ✅ Test DietSystem class
- ✅ Test DietRules class
- ✅ Test utility functions
- ✅ Test BMR calculation
- ✅ Test edge cases
- ✅ Test integration

## 💾 Menyimpan Hasil

Aplikasi dapat menyimpan hasil ke file `.txt`:
1. Setelah melihat hasil, pilih "y" untuk menyimpan
2. Masukkan nama file atau tekan Enter untuk default
3. File akan disimpan di folder yang sama

## 🔄 Menjalankan Ulang

Setelah selesai, aplikasi akan menanyakan apakah ingin menjalankan lagi:
- Pilih "y" untuk input data baru
- Pilih "n" untuk keluar

## 📞 Support

Jika mengalami masalah:
1. Periksa versi Python: `python --version`
2. Pastikan semua file ada
3. Jalankan test: `python test_system.py`
4. Periksa error message untuk detail masalah

## 🎯 Tips Penggunaan

1. **Input Akurat**: Masukkan data yang sesuai dengan kondisi nyata
2. **Konsultasi**: Hasil adalah rekomendasi umum, konsultasi dengan ahli gizi untuk program diet serius
3. **Konsistensi**: Gunakan secara berkala untuk tracking progress
4. **Variasi**: Pilih variasi menu dari rekomendasi yang diberikan

## 🔐 Keamanan Data

- Aplikasi tidak menyimpan data pribadi
- Semua perhitungan dilakukan lokal
- Tidak ada koneksi internet yang diperlukan
- Data hanya disimpan jika pengguna memilih menyimpan ke file

## 📈 Pengembangan Lanjutan

Project ini dapat dikembangkan dengan:
- Database menu yang lebih lengkap
- Perhitungan nutrisi detail
- Interface grafis (GUI)
- Web application
- Mobile app
- Integrasi dengan fitness tracker

---

**Selamat menggunakan Sistem Cerdas Rekomendasi Menu Diet!** 🍎💪