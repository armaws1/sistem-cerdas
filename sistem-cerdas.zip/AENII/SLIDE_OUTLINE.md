# 📊 SLIDE OUTLINE - Sistem Diet Cerdas

## 🎯 **SLIDE 1: TITLE SLIDE**
```
🍎 SISTEM CERDAS REKOMENDASI MENU DIET
Berdasarkan Profil Pengguna dengan Rule-Based System

Nama: [Your Name]
Kelas: [Your Class]  
Tanggal: [Date]
```

## 🎯 **SLIDE 2: PROBLEM STATEMENT**
```
❌ MASALAH YANG ADA:

• Banyak orang bingung menentukan menu diet yang tepat
• Aplikasi diet kebanyakan "black box" - tidak jelas alasannya
• Rekomendasi tidak personal sesuai profil individu
• Susah dipercaya karena tidak transparan

💡 PERTANYAAN:
"Bagaimana membuat sistem rekomendasi diet yang 
transparan, personal, dan dapat dijelaskan?"
```

## 🎯 **SLIDE 3: SOLUTION OVERVIEW**
```
✅ SOLUSI: RULE-BASED SYSTEM

🧠 Mengapa Rule-Based?
• Transparan - setiap keputusan bisa dijelaskan
• Konsisten - input sama = output sama  
• Personal - disesuaikan profil pengguna
• Mudah dimodifikasi dan dikembangkan

🎯 Input: Umur, Berat, Tinggi, Aktivitas, Tujuan Diet
🎯 Output: Menu Personal + Kalori + Tips Diet
```

## 🎯 **SLIDE 4: SYSTEM ARCHITECTURE**
```
📐 ALUR KERJA SISTEM:

Input Data → Hitung BMR → Kalori Harian → Target Kalori → Apply Rules → Menu Rekomendasi

🔧 KOMPONEN UTAMA:
1. Diet System (Perhitungan BMR & Kalori)
2. Rule Engine (Logic Menu Diet)  
3. User Interface (Input/Output)
4. Validation System (Error Handling)
```

## 🎯 **SLIDE 5: RULES & FORMULAS**
```
📊 RUMUS PERHITUNGAN:

BMR = 66 + (13.7 × berat) + (5 × tinggi) – (6.8 × umur)

Kalori Harian = BMR × Faktor Aktivitas
• Ringan: × 1.2
• Normal: × 1.35  
• Berat: × 1.5

Target Kalori:
• Turun BB: Kalori - 300
• Stabil: Kalori  
• Naik BB: Kalori + 300
```

## 🎯 **SLIDE 6: MENU RULES**
```
🍽️ LOGIC PEMILIHAN MENU:

IF Tujuan = "TURUN BB" THEN
→ Menu rendah kalori, tinggi protein, banyak sayur
→ Contoh: Oatmeal, nasi merah, sup sayur

IF Tujuan = "NAIK BB" THEN  
→ Menu tinggi kalori, protein + karbohidrat
→ Contoh: Oat susu, nasi daging, pasta

IF Tujuan = "STABIL" THEN
→ Menu seimbang, variasi nutrisi
→ Contoh: Roti gandum, nasi ayam, ikan bakar
```

## 🎯 **SLIDE 7: DEMO TIME!**
```
🎭 LIVE DEMONSTRATION

Mari kita lihat sistem bekerja!

Demo 1: Input Manual
Demo 2: 3 Kasus Otomatis

[Buka web_version.html di sini]
```

## 🎯 **SLIDE 8: DEMO RESULTS**
```
📊 HASIL DEMO:

Contoh: Andi (25 tahun, 80kg, 170cm, Normal, Turun BB)

✅ BMR: 1801 kalori/hari
✅ Target: 2131 kalori/hari (defisit 300)
✅ BMI: 27.68 (Overweight)
✅ Menu: Oatmeal → Nasi merah → Sup sayur
✅ Tips: Hindari gorengan, perbanyak protein tanpa lemak
```

## 🎯 **SLIDE 9: IMPLEMENTATION**
```
💻 IMPLEMENTASI PROJECT:

🐍 Python Version:
• 4 file modular (main, diet_system, rules, utils)
• Object-oriented design
• Comprehensive testing

🌐 Web Version:  
• HTML + JavaScript
• Responsive design
• Real-time calculation
• No installation needed

📁 12 file lengkap + dokumentasi
```

## 🎯 **SLIDE 10: FEATURES & BENEFITS**
```
⚡ FITUR UNGGULAN:

✅ Input validation & error handling
✅ BMI calculation otomatis  
✅ 4 waktu makan (sarapan, siang, malam, snack)
✅ Tips diet personal
✅ Demo mode untuk testing
✅ Cross-platform (web & desktop)

🏆 KEUNGGULAN:
• Transparan & dapat dijelaskan
• Personal sesuai profil
• Mudah digunakan
• Siap implementasi nyata
```

## 🎯 **SLIDE 11: TECHNICAL VALIDATION**
```
🔬 VALIDASI TEKNIS:

✅ Rumus BMR: Harris-Benedict Formula (medically validated)
✅ Rules Menu: Berdasarkan prinsip gizi seimbang
✅ Testing: 6 test scenarios passed
✅ Error Handling: Input validation lengkap
✅ Performance: Real-time calculation

📊 Test Results: 100% success rate
```

## 🎯 **SLIDE 12: FUTURE DEVELOPMENT**
```
🚀 PENGEMBANGAN SELANJUTNYA:

🔮 Short Term:
• Database menu lebih lengkap
• Perhitungan nutrisi detail
• Preferensi makanan personal

🔮 Long Term:  
• Mobile application
• Integration fitness tracker
• AI optimization berdasarkan feedback
• Konsultasi ahli gizi online
```

## 🎯 **SLIDE 13: CONCLUSION**
```
🎯 KESIMPULAN:

✅ Rule-Based System terbukti efektif untuk rekomendasi diet
✅ Transparan dan mudah dipahami pengguna
✅ Personal sesuai profil masing-masing individu  
✅ Implementasi lengkap dan siap digunakan

💡 KEY TAKEAWAY:
"Not all problems need complex AI. 
Sometimes the best solution is the simplest one that works."
```

## 🎯 **SLIDE 14: Q&A**
```
❓ QUESTIONS & ANSWERS

Siap menjawab pertanyaan tentang:
• Technical implementation
• Rule-based vs Machine Learning
• Medical validation
• Future development
• System scalability

🎤 Terima kasih!
```

---

## 🎨 **TIPS DESIGN SLIDE:**

### **Color Scheme:**
```
🎨 Warna yang recommended:
• Primary: #667eea (biru)
• Secondary: #ff6b6b (merah/orange)  
• Background: #f8f9fa (abu terang)
• Text: #333333 (abu gelap)
• Accent: #28a745 (hijau untuk success)
```

### **Font & Layout:**
```
📝 Typography:
• Header: Bold, 32-36pt
• Body: Regular, 24-28pt  
• Code: Monospace, 20-24pt

📐 Layout:
• Minimal text per slide
• Banyak visual/diagram
• Consistent spacing
• High contrast
```

### **Visual Elements:**
```
🎯 Tambahkan:
• Emoji untuk visual appeal
• Flowchart untuk system architecture  
• Screenshots hasil demo
• Before/after comparison
• Icons untuk features
```

---

## 🎭 **PRESENTATION FLOW:**

```
⏱️ TIMING (Total: 15-20 menit)

Slide 1-3: Opening & Problem (3 menit)
Slide 4-6: Technical Overview (4 menit)  
Slide 7-8: LIVE DEMO (8 menit) ← MAIN EVENT
Slide 9-11: Implementation & Validation (3 menit)
Slide 12-14: Future & Closing (2 menit)
```

**Remember bro: Demo adalah star of the show! Slide cuma supporting act. Focus di demo yang smooth dan impressive! 🚀✨**