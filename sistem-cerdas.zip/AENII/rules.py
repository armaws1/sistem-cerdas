"""
Rule-Based System untuk Rekomendasi Menu Diet
Berisi aturan-aturan (rules) untuk menentukan menu berdasarkan tujuan diet
"""

class DietRules:
    def __init__(self):
        """Inisialisasi rule-based system"""
        self.menu_rules = self._initialize_menu_rules()
    
    def _initialize_menu_rules(self):
        """
        Inisialisasi aturan menu diet berdasarkan tujuan
        
        Returns:
            dict: Dictionary berisi rules menu untuk setiap tujuan diet
        """
        return {
            'turun': {
                'sarapan': [
                    'Oatmeal + pisang + telur rebus',
                    'Roti gandum + alpukat + telur dadar',
                    'Smoothie protein + bayam + buah berry'
                ],
                'siang': [
                    'Nasi merah + ayam kukus + sayur bayam',
                    'Quinoa + ikan salmon + brokoli',
                    'Nasi merah + tahu tempe + capcay'
                ],
                'malam': [
                    'Sup sayur + ikan kukus',
                    'Salad ayam panggang + sayuran hijau',
                    'Sup kacang merah + sayur rebus'
                ],
                'snack': [
                    'Yogurt rendah lemak',
                    'Apel + kacang almond (sedikit)',
                    'Teh hijau + biskuit gandum (1-2 keping)'
                ]
            },
            'stabil': {
                'sarapan': [
                    'Roti gandum + selai kacang + susu rendah lemak',
                    'Nasi uduk + ayam + lalapan',
                    'Pancake oat + madu + buah'
                ],
                'siang': [
                    'Nasi putih + ayam panggang + brokoli',
                    'Mie ayam + sayur + telur',
                    'Nasi + ikan bakar + sayur asem'
                ],
                'malam': [
                    'Ikan bakar + tahu tempe + salad',
                    'Nasi + rendang + sayur',
                    'Pasta + ayam + sayuran'
                ],
                'snack': [
                    'Kacang almond',
                    'Buah pisang + yogurt',
                    'Roti + keju + susu'
                ]
            },
            'naik': {
                'sarapan': [
                    'Oat + susu full cream + telur + pisang',
                    'Roti + selai kacang + susu + buah',
                    'Nasi gudeg + ayam + telur'
                ],
                'siang': [
                    'Nasi putih + daging sapi + telur + sayur',
                    'Nasi + ayam goreng + tempe + sayur',
                    'Mie ayam + bakso + telur + sayur'
                ],
                'malam': [
                    'Pasta + ayam panggang + keju',
                    'Nasi + ikan + tahu tempe goreng',
                    'Pizza + salad + jus buah'
                ],
                'snack': [
                    'Roti + selai kacang + susu',
                    'Smoothie protein + pisang + oat',
                    'Kacang + keju + crackers'
                ]
            }
        }
    
    def get_menu_recommendation(self, diet_goal):
        """
        Mendapatkan rekomendasi menu berdasarkan tujuan diet
        
        Args:
            diet_goal (str): Tujuan diet (turun/stabil/naik)
            
        Returns:
            dict: Rekomendasi menu untuk sarapan, siang, malam, dan snack
        """
        goal = diet_goal.lower()
        
        if goal not in self.menu_rules:
            goal = 'stabil'  # Default ke maintenance jika tujuan tidak dikenali
        
        return self.menu_rules[goal]
    
    def get_detailed_recommendation(self, diet_goal):
        """
        Mendapatkan rekomendasi menu detail dengan penjelasan
        
        Args:
            diet_goal (str): Tujuan diet
            
        Returns:
            dict: Rekomendasi menu dengan penjelasan detail
        """
        menu = self.get_menu_recommendation(diet_goal)
        goal = diet_goal.lower()
        
        explanations = {
            'turun': {
                'focus': 'Menu rendah kalori, tinggi protein, banyak sayur',
                'tips': 'Hindari gorengan, perbanyak sayur dan protein tanpa lemak'
            },
            'stabil': {
                'focus': 'Menu seimbang dengan porsi normal',
                'tips': 'Jaga keseimbangan karbohidrat, protein, dan lemak sehat'
            },
            'naik': {
                'focus': 'Menu tinggi kalori, protein, dan karbohidrat',
                'tips': 'Tambah porsi, protein, dan lemak sehat untuk menambah berat badan'
            }
        }
        
        explanation = explanations.get(goal, explanations['stabil'])
        
        return {
            'menu': menu,
            'focus': explanation['focus'],
            'tips': explanation['tips']
        }
    
    def apply_rules(self, user_profile):
        """
        Menerapkan rules berdasarkan profil pengguna
        
        Args:
            user_profile (dict): Profil pengguna dari DietSystem
            
        Returns:
            dict: Hasil penerapan rules dengan rekomendasi lengkap
        """
        diet_goal = user_profile['user_data']['diet_goal']
        recommendation = self.get_detailed_recommendation(diet_goal)
        
        return {
            'user_profile': user_profile,
            'menu_recommendation': recommendation['menu'],
            'diet_focus': recommendation['focus'],
            'diet_tips': recommendation['tips'],
            'rule_applied': f"Rule untuk tujuan '{diet_goal}' berhasil diterapkan"
        }