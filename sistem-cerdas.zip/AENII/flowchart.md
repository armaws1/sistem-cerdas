# Flowchart Sistem Cerdas Rekomendasi Menu Diet

## 🔄 Alur Kerja Sistem (Detailed Flowchart)

```
                              START
                                │
                                ▼
                    ┌─────────────────────────┐
                    │    Tampilkan Menu       │
                    │    1. Mode Normal       │
                    │    2. Mode Demo         │
                    └─────────────────────────┘
                                │
                                ▼
                    ┌─────────────────────────┐
                    │    Pilih Mode?          │
                    │                         │
                    └─────────────────────────┘
                           │            │
                    Mode Demo│            │Mode Normal
                           ▼            ▼
              ┌─────────────────┐    ┌─────────────────────────┐
              │  Jalankan Demo  │    │     INPUT DATA          │
              │  dengan 3 Contoh│    │                         │
              │  Data Preset    │    │  • Umur (10-100)        │
              └─────────────────┘    │  • Berat (30-200 kg)    │
                           │         │  • Tinggi (100-250 cm)  │
                           │         │  • Aktivitas (1/2/3)    │
                           │         │  • Tujuan Diet (1/2/3)  │
                           │         └─────────────────────────┘
                           │                      │
                           │                      ▼
                           │         ┌─────────────────────────┐
                           │         │    VALIDASI INPUT       │
                           │         │                         │
                           │         │  Valid? ────────No──────┐
                           │         └─────────────────────────┘│
                           │                      │Yes          │
                           │                      ▼             │
                           │         ┌─────────────────────────┐│
                           │         │   HITUNG BMR            ││
                           │         │                         ││
                           │         │ BMR = 66 + (13.7×berat)││
                           │         │     + (5×tinggi)        ││
                           │         │     - (6.8×umur)        ││
                           │         └─────────────────────────┘│
                           │                      │             │
                           │                      ▼             │
                           │         ┌─────────────────────────┐│
                           │         │ HITUNG KALORI AKTIVITAS ││
                           │         │                         ││
                           │         │ Ringan  → BMR × 1.2     ││
                           │         │ Normal  → BMR × 1.35    ││
                           │         │ Berat   → BMR × 1.5     ││
                           │         └─────────────────────────┘│
                           │                      │             │
                           │                      ▼             │
                           │         ┌─────────────────────────┐│
                           │         │ TENTUKAN TARGET KALORI  ││
                           │         │                         ││
                           │         │ Turun  → Kalori - 300   ││
                           │         │ Stabil → Kalori         ││
                           │         │ Naik   → Kalori + 300   ││
                           │         └─────────────────────────┘│
                           │                      │             │
                           │                      ▼             │
                           │         ┌─────────────────────────┐│
                           │         │   TERAPKAN RULES        ││
                           │         │                         ││
                           │         │ IF Tujuan = "turun"     ││
                           │         │   THEN Menu Diet A      ││
                           │         │ IF Tujuan = "stabil"    ││
                           │         │   THEN Menu Diet B      ││
                           │         │ IF Tujuan = "naik"      ││
                           │         │   THEN Menu Diet C      ││
                           │         └─────────────────────────┘│
                           │                      │             │
                           │                      ▼             │
                           │         ┌─────────────────────────┐│
                           │         │   HITUNG BMI            ││
                           │         │                         ││
                           │         │ BMI = berat/(tinggi²)   ││
                           │         │ Kategori BMI            ││
                           │         └─────────────────────────┘│
                           │                      │             │
                           │                      ▼             │
                           └─────────────────────▶┌─────────────────────────┐│
                                                  │   TAMPILKAN HASIL       ││
                                                  │                         ││
                                                  │ • Profil Pengguna       ││
                                                  │ • BMR & Kalori          ││
                                                  │ • Kategori Diet         ││
                                                  │ • Menu Rekomendasi      ││
                                                  │ • BMI & Kategori        ││
                                                  │ • Tips Diet             ││
                                                  └─────────────────────────┘│
                                                               │             │
                                                               ▼             │
                                                  ┌─────────────────────────┐│
                                                  │   SIMPAN KE FILE?       ││
                                                  │                         ││
                                                  │   Ya ──────────No       ││
                                                  └─────────────────────────┘│
                                                       │                     ││
                                                       ▼                     ││
                                                  ┌─────────────────────────┐││
                                                  │   SIMPAN HASIL          │││
                                                  │   KE FILE TXT           │││
                                                  └─────────────────────────┘││
                                                               │             ││
                                                               ▼             ││
                                                  ┌─────────────────────────┐││
                                                  │   JALANKAN LAGI?        │││
                                                  │                         │││
                                                  │   Ya ──────────No       │││
                                                  └─────────────────────────┘││
                                                       │                     │││
                                                       │No                   │││
                                                       ▼                     │││
                                                  ┌─────────────────────────┐│││
                                                  │        END              ││││
                                                  └─────────────────────────┘│││
                                                                             │││
                                                  ┌──────────────────────────┘││
                                                  │ ERROR: Tampilkan Pesan    ││
                                                  │ Error & Minta Input Ulang ││
                                                  └───────────────────────────┘│
                                                                              │
                                                  ┌───────────────────────────┘
                                                  │ Ya: Kembali ke START
                                                  └─────────────────────────────┐
                                                                                │
                                                                                ▼
                                                                           START
```

## 🧠 Decision Tree untuk Rule-Based System

```
                            INPUT TUJUAN DIET
                                    │
                    ┌───────────────┼───────────────┐
                    │               │               │
                 TURUN           STABIL           NAIK
                    │               │               │
                    ▼               ▼               ▼
        ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
        │   RULE SET A    │ │   RULE SET B    │ │   RULE SET C    │
        │                 │ │                 │ │                 │
        │ Target:         │ │ Target:         │ │ Target:         │
        │ Kalori - 300    │ │ Kalori Normal   │ │ Kalori + 300    │
        │                 │ │                 │ │                 │
        │ Menu Focus:     │ │ Menu Focus:     │ │ Menu Focus:     │
        │ • Rendah Kalori │ │ • Seimbang      │ │ • Tinggi Kalori │
        │ • Tinggi Protein│ │ • Variasi       │ │ • Tinggi Protein│
        │ • Banyak Sayur  │ │ • Maintenance   │ │ • Karbohidrat   │
        │                 │ │                 │ │                 │
        │ Sarapan:        │ │ Sarapan:        │ │ Sarapan:        │
        │ • Oatmeal+telur │ │ • Roti+selai    │ │ • Oat+susu full │
        │ • Roti gandum   │ │ • Nasi uduk     │ │ • Roti+selai    │
        │ • Smoothie      │ │ • Pancake oat   │ │ • Nasi gudeg    │
        │                 │ │                 │ │                 │
        │ Siang:          │ │ Siang:          │ │ Siang:          │
        │ • Nasi merah    │ │ • Nasi+ayam     │ │ • Nasi+daging   │
        │ • Quinoa+ikan   │ │ • Mie ayam      │ │ • Nasi+ayam     │
        │ • Nasi+tahu     │ │ • Nasi+ikan     │ │ • Mie+bakso     │
        │                 │ │                 │ │                 │
        │ Malam:          │ │ Malam:          │ │ Malam:          │
        │ • Sup sayur     │ │ • Ikan bakar    │ │ • Pasta+ayam    │
        │ • Salad ayam    │ │ • Nasi+rendang  │ │ • Nasi+ikan     │
        │ • Sup kacang    │ │ • Pasta+ayam    │ │ • Pizza+salad   │
        │                 │ │                 │ │                 │
        │ Snack:          │ │ Snack:          │ │ Snack:          │
        │ • Yogurt        │ │ • Almond        │ │ • Roti+selai    │
        │ • Apel+almond   │ │ • Pisang+yogurt │ │ • Smoothie      │
        │ • Teh+biskuit   │ │ • Roti+keju     │ │ • Kacang+keju   │
        └─────────────────┘ └─────────────────┘ └─────────────────┘
```

## ⚙️ Proses Validasi Input

```
                        INPUT VALIDATION FLOW
                                │
                                ▼
                    ┌─────────────────────────┐
                    │      VALIDASI UMUR      │
                    │                         │
                    │   10 ≤ umur ≤ 100?     │
                    └─────────────────────────┘
                            │        │
                           Yes       No
                            │        │
                            ▼        ▼
                    ┌─────────────────────────┐
                    │   VALIDASI BERAT BADAN  │    ERROR: "Umur harus 10-100"
                    │                         │         │
                    │   30 ≤ berat ≤ 200?    │         │
                    └─────────────────────────┘         │
                            │        │                  │
                           Yes       No                 │
                            │        │                  │
                            ▼        ▼                  │
                    ┌─────────────────────────┐         │
                    │   VALIDASI TINGGI BADAN │    ERROR: "Berat 30-200 kg"
                    │                         │         │
                    │  100 ≤ tinggi ≤ 250?   │         │
                    └─────────────────────────┘         │
                            │        │                  │
                           Yes       No                 │
                            │        │                  │
                            ▼        ▼                  │
                    ┌─────────────────────────┐         │
                    │   VALIDASI AKTIVITAS    │    ERROR: "Tinggi 100-250 cm"
                    │                         │         │
                    │ ringan/normal/berat?    │         │
                    └─────────────────────────┘         │
                            │        │                  │
                           Yes       No                 │
                            │        │                  │
                            ▼        ▼                  │
                    ┌─────────────────────────┐         │
                    │   VALIDASI TUJUAN       │    ERROR: "Pilih 1/2/3"
                    │                         │         │
                    │  turun/stabil/naik?     │         │
                    └─────────────────────────┘         │
                            │        │                  │
                           Yes       No                 │
                            │        │                  │
                            ▼        ▼                  │
                    ┌─────────────────────────┐         │
                    │    INPUT VALID          │    ERROR: "Pilih 1/2/3"
                    │    LANJUT PROSES        │         │
                    └─────────────────────────┘         │
                                                        │
                                                        ▼
                                               ┌─────────────────────────┐
                                               │   KEMBALI KE INPUT      │
                                               │   YANG BERMASALAH       │
                                               └─────────────────────────┘
```

## 🔄 State Diagram Sistem

```
    [IDLE] ──start──▶ [INPUT_MODE]
                           │
                           │user_input
                           ▼
                      [VALIDATING] ──invalid──▶ [ERROR_STATE]
                           │                         │
                           │valid                    │retry
                           ▼                         │
                      [CALCULATING] ◀───────────────┘
                           │
                           │bmr_done
                           ▼
                      [RULE_PROCESSING]
                           │
                           │rules_applied
                           ▼
                      [DISPLAYING_RESULTS]
                           │
                           │show_complete
                           ▼
                      [SAVE_OPTION] ──no_save──▶ [RESTART_OPTION]
                           │                           │
                           │save                       │
                           ▼                           │
                      [SAVING_FILE] ──────────────────┘
                                                       │
                                                       │restart
                                                       ▼
                                                  [INPUT_MODE]
                                                       │
                                                       │exit
                                                       ▼
                                                    [END]
```

## 📊 Data Flow Diagram

```
                    USER INPUT DATA
                           │
                           ▼
                  ┌─────────────────┐
                  │  Input Handler  │
                  │   (utils.py)    │
                  └─────────────────┘
                           │
                           ▼
                  ┌─────────────────┐
                  │   Validation    │
                  │   Functions     │
                  └─────────────────┘
                           │
                           ▼
                  ┌─────────────────┐
                  │  Diet System    │
                  │ (diet_system.py)│
                  └─────────────────┘
                           │
                    ┌──────┴──────┐
                    ▼             ▼
            ┌─────────────┐ ┌─────────────┐
            │ BMR Calc    │ │ Calorie     │
            │ Function    │ │ Calculator  │
            └─────────────┘ └─────────────┘
                    │             │
                    └──────┬──────┘
                           ▼
                  ┌─────────────────┐
                  │  Target Calorie │
                  │   Determiner    │
                  └─────────────────┘
                           │
                           ▼
                  ┌─────────────────┐
                  │   Rule Engine   │
                  │   (rules.py)    │
                  └─────────────────┘
                           │
                    ┌──────┴──────┐
                    ▼             ▼
            ┌─────────────┐ ┌─────────────┐
            │ Menu Rules  │ │ Diet Tips   │
            │ Database    │ │ Generator   │
            └─────────────┘ └─────────────┘
                    │             │
                    └──────┬──────┘
                           ▼
                  ┌─────────────────┐
                  │ Output Handler  │
                  │   (utils.py)    │
                  └─────────────────┘
                           │
                    ┌──────┴──────┐
                    ▼             ▼
            ┌─────────────┐ ┌─────────────┐
            │ Screen      │ │ File        │
            │ Display     │ │ Output      │
            └─────────────┘ └─────────────┘
```

Flowchart ini menunjukkan alur kerja lengkap sistem dari input hingga output, termasuk validasi, perhitungan, penerapan rules, dan penyimpanan hasil.