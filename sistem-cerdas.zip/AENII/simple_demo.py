"""
Demo Sederhana Sistem Diet - Bisa dijalankan di online Python compiler
Copy paste code ini ke repl.it, trinket.io, atau online Python compiler lainnya
"""

def hitung_bmr(umur, berat, tinggi):
    """Hitung BMR menggunakan rumus Harris-Benedict"""
    return 66 + (13.7 * berat) + (5 * tinggi) - (6.8 * umur)

def hitung_kalori_harian(bmr, aktivitas):
    """Hitung kalori harian berdasarkan aktivitas"""
    faktor = {"ringan": 1.2, "normal": 1.35, "berat": 1.5}
    return bmr * faktor.get(aktivitas, 1.35)

def tentukan_target_kalori(kalori_harian, tujuan):
    """Tentukan target kalori berdasarkan tujuan"""
    if tujuan == "turun":
        return kalori_harian - 300, "Defisit Kalori (Turun BB)"
    elif tujuan == "naik":
        return kalori_harian + 300, "Surplus Kalori (Naik BB)"
    else:
        return kalori_harian, "Maintenance (Stabil)"

def get_menu_rekomendasi(tujuan):
    """Dapatkan rekomendasi menu berdasarkan tujuan"""
    menu_rules = {
        "turun": {
            "sarapan": "Oatmeal + pisang + telur rebus",
            "siang": "Nasi merah + ayam kukus + sayur bayam", 
            "malam": "Sup sayur + ikan kukus",
            "snack": "Yogurt rendah lemak",
            "tips": "Menu rendah kalori, tinggi protein, banyak sayur"
        },
        "stabil": {
            "sarapan": "Roti gandum + selai kacang + susu rendah lemak",
            "siang": "Nasi putih + ayam panggang + brokoli",
            "malam": "Ikan bakar + tahu tempe + salad", 
            "snack": "Kacang almond",
            "tips": "Menu seimbang dengan porsi normal"
        },
        "naik": {
            "sarapan": "Oat + susu full cream + telur + pisang",
            "siang": "Nasi putih + daging sapi + telur + sayur",
            "malam": "Pasta + ayam panggang + keju",
            "snack": "Roti + selai kacang + susu", 
            "tips": "Menu tinggi kalori, protein, dan karbohidrat"
        }
    }
    return menu_rules.get(tujuan, menu_rules["stabil"])

def demo_sistem_diet():
    """Demo sistem diet dengan 3 contoh kasus"""
    
    print("🍎 DEMO SISTEM CERDAS REKOMENDASI MENU DIET")
    print("=" * 60)
    
    # 3 Contoh kasus
    contoh_kasus = [
        {
            "nama": "Andi - Turun Berat Badan",
            "umur": 25, "berat": 80, "tinggi": 170,
            "aktivitas": "normal", "tujuan": "turun"
        },
        {
            "nama": "Sari - Naik Berat Badan", 
            "umur": 22, "berat": 45, "tinggi": 160,
            "aktivitas": "ringan", "tujuan": "naik"
        },
        {
            "nama": "Budi - Menjaga Berat Badan",
            "umur": 30, "berat": 70, "tinggi": 175, 
            "aktivitas": "berat", "tujuan": "stabil"
        }
    ]
    
    for i, kasus in enumerate(contoh_kasus, 1):
        print(f"\n📋 CONTOH {i}: {kasus['nama']}")
        print("-" * 50)
        
        # Input data
        print(f"👤 Profil:")
        print(f"   Umur: {kasus['umur']} tahun")
        print(f"   Berat: {kasus['berat']} kg") 
        print(f"   Tinggi: {kasus['tinggi']} cm")
        print(f"   Aktivitas: {kasus['aktivitas'].title()}")
        print(f"   Tujuan: {kasus['tujuan'].title()}")
        
        # Perhitungan
        bmr = hitung_bmr(kasus['umur'], kasus['berat'], kasus['tinggi'])
        kalori_harian = hitung_kalori_harian(bmr, kasus['aktivitas'])
        target_kalori, kategori = tentukan_target_kalori(kalori_harian, kasus['tujuan'])
        
        # Hitung BMI
        tinggi_m = kasus['tinggi'] / 100
        bmi = kasus['berat'] / (tinggi_m ** 2)
        
        print(f"\n🔥 Hasil Perhitungan:")
        print(f"   BMR: {bmr:.1f} kalori/hari")
        print(f"   Kebutuhan Kalori: {kalori_harian:.1f} kalori/hari")
        print(f"   Target Kalori: {target_kalori:.1f} kalori/hari")
        print(f"   BMI: {bmi:.1f}")
        print(f"   Kategori: {kategori}")
        
        # Menu rekomendasi
        menu = get_menu_rekomendasi(kasus['tujuan'])
        print(f"\n🍽️ Rekomendasi Menu:")
        print(f"   Tips: {menu['tips']}")
        print(f"   🌅 Sarapan: {menu['sarapan']}")
        print(f"   🌞 Siang: {menu['siang']}")
        print(f"   🌙 Malam: {menu['malam']}")
        print(f"   🍎 Snack: {menu['snack']}")
        
        if i < len(contoh_kasus):
            input(f"\n⏳ Tekan Enter untuk contoh {i+1}...")
    
    print(f"\n{'='*60}")
    print("✅ DEMO SELESAI!")
    print("💡 Ini menunjukkan bagaimana rule-based system bekerja")
    print("🎯 Setiap tujuan diet menghasilkan rekomendasi berbeda")
    print("="*60)

def input_manual():
    """Mode input manual untuk testing"""
    print("\n🔧 MODE INPUT MANUAL")
    print("-" * 30)
    
    try:
        umur = int(input("Masukkan umur (tahun): "))
        berat = float(input("Masukkan berat badan (kg): "))
        tinggi = float(input("Masukkan tinggi badan (cm): "))
        
        print("\nPilih aktivitas:")
        print("1. Ringan")
        print("2. Normal") 
        print("3. Berat")
        aktivitas_pilihan = int(input("Pilihan (1/2/3): "))
        aktivitas = ["ringan", "normal", "berat"][aktivitas_pilihan - 1]
        
        print("\nPilih tujuan:")
        print("1. Turun berat badan")
        print("2. Menjaga berat badan")
        print("3. Naik berat badan")
        tujuan_pilihan = int(input("Pilihan (1/2/3): "))
        tujuan = ["turun", "stabil", "naik"][tujuan_pilihan - 1]
        
        # Perhitungan
        bmr = hitung_bmr(umur, berat, tinggi)
        kalori_harian = hitung_kalori_harian(bmr, aktivitas)
        target_kalori, kategori = tentukan_target_kalori(kalori_harian, tujuan)
        
        # Hasil
        print(f"\n📊 HASIL ANALISIS:")
        print(f"BMR: {bmr:.1f} kalori/hari")
        print(f"Kebutuhan Kalori: {kalori_harian:.1f} kalori/hari") 
        print(f"Target Kalori: {target_kalori:.1f} kalori/hari")
        print(f"Kategori: {kategori}")
        
        # Menu
        menu = get_menu_rekomendasi(tujuan)
        print(f"\n🍽️ REKOMENDASI MENU:")
        print(f"Tips: {menu['tips']}")
        print(f"Sarapan: {menu['sarapan']}")
        print(f"Siang: {menu['siang']}")
        print(f"Malam: {menu['malam']}")
        print(f"Snack: {menu['snack']}")
        
    except (ValueError, IndexError):
        print("❌ Input tidak valid!")

# MAIN PROGRAM
if __name__ == "__main__":
    print("🚀 Pilih mode:")
    print("1. Demo Otomatis (3 contoh)")
    print("2. Input Manual")
    
    try:
        pilihan = input("\nPilihan Anda (1/2): ").strip()
        
        if pilihan == "1":
            demo_sistem_diet()
        elif pilihan == "2":
            input_manual()
        else:
            print("Demo otomatis dijalankan...")
            demo_sistem_diet()
            
    except KeyboardInterrupt:
        print("\n\n👋 Terima kasih!")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("Menjalankan demo...")
        demo_sistem_diet()