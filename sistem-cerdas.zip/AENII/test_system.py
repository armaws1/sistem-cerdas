"""
Test Script untuk Sistem Cerdas Rekomendasi Menu Diet
Script untuk testing semua fungsi sistem
"""

from diet_system import DietSystem
from rules import DietRules
from utils import calculate_bmi, validate_input_range

def test_diet_system():
    """Test DietSystem class"""
    print("🧪 Testing DietSystem...")
    
    diet_system = DietSystem()
    
    # Test case 1: Normal case
    profile = diet_system.process_user_input(25, 70, 170, 'normal', 'stabil')
    
    assert profile['user_data']['age'] == 25
    assert profile['user_data']['weight'] == 70
    assert profile['bmr'] > 0
    assert profile['daily_calories'] > profile['bmr']
    
    print("✅ DietSystem test passed!")
    return True

def test_rules_system():
    """Test DietRules class"""
    print("🧪 Testing DietRules...")
    
    diet_rules = DietRules()
    
    # Test menu recommendation
    menu_turun = diet_rules.get_menu_recommendation('turun')
    menu_stabil = diet_rules.get_menu_recommendation('stabil')
    menu_naik = diet_rules.get_menu_recommendation('naik')
    
    assert 'sarapan' in menu_turun
    assert 'siang' in menu_turun
    assert 'malam' in menu_turun
    assert 'snack' in menu_turun
    
    assert len(menu_turun['sarapan']) > 0
    assert len(menu_stabil['sarapan']) > 0
    assert len(menu_naik['sarapan']) > 0
    
    print("✅ DietRules test passed!")
    return True

def test_utils_functions():
    """Test utility functions"""
    print("🧪 Testing Utils...")
    
    # Test BMI calculation
    bmi, category = calculate_bmi(70, 170)
    assert 20 <= bmi <= 30  # Reasonable BMI range
    assert category in ['Underweight', 'Normal', 'Overweight', 'Obese']
    
    # Test validation
    assert validate_input_range(25, 10, 100, 'umur') == True
    assert validate_input_range(5, 10, 100, 'umur') == False
    
    print("✅ Utils test passed!")
    return True

def test_integration():
    """Test integrasi semua komponen"""
    print("🧪 Testing Integration...")
    
    diet_system = DietSystem()
    diet_rules = DietRules()
    
    # Test full workflow
    user_profile = diet_system.process_user_input(25, 70, 170, 'normal', 'turun')
    results = diet_rules.apply_rules(user_profile)
    
    assert 'user_profile' in results
    assert 'menu_recommendation' in results
    assert 'diet_focus' in results
    assert 'diet_tips' in results
    
    # Verify menu structure
    menu = results['menu_recommendation']
    assert all(key in menu for key in ['sarapan', 'siang', 'malam', 'snack'])
    assert all(len(menu[key]) > 0 for key in menu.keys())
    
    print("✅ Integration test passed!")
    return True

def test_edge_cases():
    """Test edge cases dan boundary values"""
    print("🧪 Testing Edge Cases...")
    
    diet_system = DietSystem()
    
    # Test minimum values
    profile_min = diet_system.process_user_input(10, 30, 100, 'ringan', 'turun')
    assert profile_min['bmr'] > 0
    
    # Test maximum values  
    profile_max = diet_system.process_user_input(100, 200, 250, 'berat', 'naik')
    assert profile_max['bmr'] > 0
    
    # Test different goals
    for goal in ['turun', 'stabil', 'naik']:
        profile = diet_system.process_user_input(25, 70, 170, 'normal', goal)
        assert profile['user_data']['diet_goal'] == goal
    
    # Test different activities
    for activity in ['ringan', 'normal', 'berat']:
        profile = diet_system.process_user_input(25, 70, 170, activity, 'stabil')
        assert profile['user_data']['activity_level'] == activity
    
    print("✅ Edge cases test passed!")
    return True

def test_bmr_calculation():
    """Test akurasi perhitungan BMR"""
    print("🧪 Testing BMR Calculation...")
    
    diet_system = DietSystem()
    
    # Test case dengan nilai yang diketahui
    # Pria 25 tahun, 70kg, 170cm
    # BMR = 66 + (13.7 × 70) + (5 × 170) – (6.8 × 25)
    # BMR = 66 + 959 + 850 - 170 = 1705
    
    profile = diet_system.process_user_input(25, 70, 170, 'normal', 'stabil')
    expected_bmr = 66 + (13.7 * 70) + (5 * 170) - (6.8 * 25)
    
    assert abs(profile['bmr'] - expected_bmr) < 0.1  # Toleransi floating point
    
    print(f"   Expected BMR: {expected_bmr}")
    print(f"   Calculated BMR: {profile['bmr']}")
    print("✅ BMR calculation test passed!")
    return True

def run_all_tests():
    """Menjalankan semua test"""
    print("🚀 MEMULAI TESTING SISTEM DIET")
    print("="*50)
    
    tests = [
        test_diet_system,
        test_rules_system, 
        test_utils_functions,
        test_bmr_calculation,
        test_edge_cases,
        test_integration
    ]
    
    passed = 0
    failed = 0
    
    for test_func in tests:
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
                print(f"❌ {test_func.__name__} failed!")
        except Exception as e:
            failed += 1
            print(f"❌ {test_func.__name__} error: {str(e)}")
    
    print("\n" + "="*50)
    print("📊 HASIL TESTING:")
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    print(f"📈 Success Rate: {(passed/(passed+failed)*100):.1f}%")
    
    if failed == 0:
        print("\n🎉 SEMUA TEST BERHASIL!")
        print("✅ Sistem siap digunakan!")
    else:
        print(f"\n⚠️ Ada {failed} test yang gagal!")
        print("🔧 Silakan periksa kode!")
    
    return failed == 0

if __name__ == "__main__":
    try:
        success = run_all_tests()
        
        if success:
            print("\n💡 Sistem telah diverifikasi dan siap digunakan!")
            print("🚀 Jalankan 'python main.py' untuk memulai aplikasi")
            print("🎭 Atau 'python run_demo.py' untuk melihat demo")
        
    except KeyboardInterrupt:
        print("\n\n⚠️ Testing dihentikan oleh pengguna.")
    except Exception as e:
        print(f"\n❌ Error dalam testing: {str(e)}")
        print("🔧 Silakan periksa instalasi Python dan file sistem.")