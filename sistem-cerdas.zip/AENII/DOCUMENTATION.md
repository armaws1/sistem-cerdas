# Dokumentasi Lengkap Sistem Cerdas Rekomendasi Menu Diet

## 📋 Daftar Isi
1. [Pengenalan Sistem](#pengenalan-sistem)
2. [Arsitektur Sistem](#arsitektur-sistem)
3. [Rule-Based System](#rule-based-system)
4. [Flowchart Sistem](#flowchart-sistem)
5. [Implementasi Detail](#implementasi-detail)
6. [Cara Penggunaan](#cara-penggunaan)
7. [Contoh Penggunaan](#contoh-penggunaan)

## 🎯 Pengenalan Sistem

### Definisi
Sistem Cerdas Rekomendasi Menu Diet adalah aplikasi berbasis **Rule-Based System (Expert System)** yang memberikan rekomendasi menu diet personal berdasarkan profil pengguna. Sistem ini menggunakan pendekatan logika aturan yang dapat dijelaskan secara transparan, bukan Machine Learning.

### Keunggulan Rule-Based System
- **Transparan**: Setiap keputusan dapat dijelaskan
- **Konsisten**: Hasil sama untuk input yang sama
- **Mudah dimodifikasi**: Rules dapat diubah tanpa training ulang
- **Cepat**: Tidak memerlukan proses training yang lama

## 🏗️ Arsitektur Sistem

### Komponen Utama

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   User Input    │───▶│   Diet System   │───▶│   Rule Engine   │
│                 │    │                 │    │                 │
│ - Umur          │    │ - BMR Calc      │    │ - Menu Rules    │
│ - Berat         │    │ - Calorie Calc  │    │ - Diet Logic    │
│ - Tinggi        │    │ - Goal Setting  │    │ - Recommendations│
│ - Aktivitas     │    │                 │    │                 │
│ - Tujuan        │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                │                        │
                                ▼                        ▼
                       ┌─────────────────┐    ┌─────────────────┐
                       │   Validation    │    │     Output      │
                       │                 │    │                 │
                       │ - Input Check   │    │ - Menu Lists    │
                       │ - Range Valid   │    │ - Calorie Info  │
                       │ - Error Handle  │    │ - Diet Tips     │
                       └─────────────────┘    └─────────────────┘
```

### File Structure
```
diet-recommendation-system/
├── main.py              # Entry point aplikasi
├── diet_system.py       # Core logic perhitungan
├── rules.py            # Rule-based system
├── utils.py            # Utility functions
├── README.md           # Dokumentasi utama
├── DOCUMENTATION.md    # Dokumentasi detail
└── examples/
    └── sample_output.txt # Contoh output
```

## 🧠 Rule-Based System

### Struktur Rules

#### 1. Rules Perhitungan BMR
```python
IF user_input_valid THEN
    BMR = 66 + (13.7 × berat) + (5 × tinggi) – (6.8 × umur)
```

#### 2. Rules Aktivitas
```python
IF aktivitas == "ringan" THEN kalori_harian = BMR × 1.2
IF aktivitas == "normal" THEN kalori_harian = BMR × 1.35  
IF aktivitas == "berat" THEN kalori_harian = BMR × 1.5
```

#### 3. Rules Tujuan Diet
```python
IF tujuan == "turun" THEN 
    target_kalori = kalori_harian - 300
    kategori = "Defisit Kalori"
    
IF tujuan == "stabil" THEN
    target_kalori = kalori_harian
    kategori = "Maintenance"
    
IF tujuan == "naik" THEN
    target_kalori = kalori_harian + 300
    kategori = "Surplus Kalori"
```

#### 4. Rules Menu Diet

**Rule A: Turun Berat Badan**
```python
IF tujuan == "turun" THEN
    sarapan = ["Oatmeal + pisang + telur rebus", 
               "Roti gandum + alpukat + telur dadar",
               "Smoothie protein + bayam + buah berry"]
    siang = ["Nasi merah + ayam kukus + sayur bayam",
             "Quinoa + ikan salmon + brokoli", 
             "Nasi merah + tahu tempe + capcay"]
    malam = ["Sup sayur + ikan kukus",
             "Salad ayam panggang + sayuran hijau",
             "Sup kacang merah + sayur rebus"]
    snack = ["Yogurt rendah lemak",
             "Apel + kacang almond (sedikit)",
             "Teh hijau + biskuit gandum (1-2 keping)"]
    focus = "Menu rendah kalori, tinggi protein, banyak sayur"
```

**Rule B: Menjaga Berat Badan**
```python
IF tujuan == "stabil" THEN
    sarapan = ["Roti gandum + selai kacang + susu rendah lemak",
               "Nasi uduk + ayam + lalapan",
               "Pancake oat + madu + buah"]
    siang = ["Nasi putih + ayam panggang + brokoli",
             "Mie ayam + sayur + telur",
             "Nasi + ikan bakar + sayur asem"]
    malam = ["Ikan bakar + tahu tempe + salad",
             "Nasi + rendang + sayur",
             "Pasta + ayam + sayuran"]
    snack = ["Kacang almond",
             "Buah pisang + yogurt", 
             "Roti + keju + susu"]
    focus = "Menu seimbang dengan porsi normal"
```

**Rule C: Menaikkan Berat Badan**
```python
IF tujuan == "naik" THEN
    sarapan = ["Oat + susu full cream + telur + pisang",
               "Roti + selai kacang + susu + buah",
               "Nasi gudeg + ayam + telur"]
    siang = ["Nasi putih + daging sapi + telur + sayur",
             "Nasi + ayam goreng + tempe + sayur",
             "Mie ayam + bakso + telur + sayur"]
    malam = ["Pasta + ayam panggang + keju",
             "Nasi + ikan + tahu tempe goreng",
             "Pizza + salad + jus buah"]
    snack = ["Roti + selai kacang + susu",
             "Smoothie protein + pisang + oat",
             "Kacang + keju + crackers"]
    focus = "Menu tinggi kalori, protein, dan karbohidrat"
```

## 📊 Flowchart Sistem

```
START
  │
  ▼
┌─────────────────┐
│   Input Data    │
│   Pengguna      │
└─────────────────┘
  │
  ▼
┌─────────────────┐
│   Validasi      │
│   Input         │
└─────────────────┘
  │
  ▼
┌─────────────────┐
│   Hitung BMR    │
│ (Harris-Benedict)│
└─────────────────┘
  │
  ▼
┌─────────────────┐
│ Hitung Kalori   │
│ Berdasarkan     │
│ Aktivitas       │
└─────────────────┘
  │
  ▼
┌─────────────────┐
│ Tentukan Target │
│ Kalori Sesuai   │
│ Tujuan Diet     │
└─────────────────┘
  │
  ▼
┌─────────────────┐
│ Terapkan Rules  │
│ Menu Diet       │
└─────────────────┘
  │
  ▼
┌─────────────────┐
│ Tampilkan       │
│ Rekomendasi     │
└─────────────────┘
  │
  ▼
┌─────────────────┐
│ Simpan Hasil    │
│ (Opsional)      │
└─────────────────┘
  │
  ▼
END
```

## 💻 Implementasi Detail

### Class DietSystem
**Fungsi**: Core logic untuk perhitungan BMR dan kalori
**Methods**:
- `input_user_data()`: Menyimpan data pengguna
- `calculate_bmr()`: Menghitung BMR dengan rumus Harris-Benedict
- `calculate_daily_calories()`: Menghitung kebutuhan kalori harian
- `determine_target_calories()`: Menentukan target kalori sesuai tujuan
- `process_user_input()`: Memproses semua input sekaligus

### Class DietRules
**Fungsi**: Rule-based system untuk rekomendasi menu
**Methods**:
- `get_menu_recommendation()`: Mendapatkan menu berdasarkan tujuan
- `get_detailed_recommendation()`: Mendapatkan menu dengan penjelasan
- `apply_rules()`: Menerapkan rules pada profil pengguna

### Utils Functions
**Fungsi**: Utility untuk input/output dan validasi
**Functions**:
- `get_user_input()`: Input dengan validasi
- `display_results()`: Menampilkan hasil dengan format rapi
- `calculate_bmi()`: Menghitung BMI
- `save_results_to_file()`: Menyimpan hasil ke file

## 🚀 Cara Penggunaan

### Instalasi
1. Pastikan Python 3.x terinstall
2. Download semua file project
3. Buka terminal/command prompt
4. Navigate ke folder project

### Menjalankan Aplikasi
```bash
python main.py
```

### Mode Penggunaan
1. **Mode Normal**: Input manual dari pengguna
2. **Mode Demo**: Contoh dengan data preset

### Input yang Diperlukan
- **Umur**: 10-100 tahun
- **Berat Badan**: 30-200 kg
- **Tinggi Badan**: 100-250 cm
- **Aktivitas**: Ringan/Normal/Berat
- **Tujuan**: Turun/Stabil/Naik berat badan

## 📝 Contoh Penggunaan

### Contoh Input
```
Umur: 25 tahun
Berat Badan: 80 kg
Tinggi Badan: 170 cm
Aktivitas: Normal (olahraga 1-3x seminggu)
Tujuan: Turun berat badan
```

### Contoh Output
```
📊 HASIL ANALISIS PROFIL ANDA
BMR: 1801.0 kalori/hari
Kebutuhan Kalori Harian: 2431.35 kalori/hari
Target Kalori: 2131.35 kalori/hari
Kategori Diet: Defisit Kalori (Turun Berat Badan)

🍽️ REKOMENDASI MENU DIET ANDA
Fokus Diet: Menu rendah kalori, tinggi protein, banyak sayur

🌅 SARAPAN:
1. Oatmeal + pisang + telur rebus
2. Roti gandum + alpukat + telur dadar
3. Smoothie protein + bayam + buah berry

🌞 MAKAN SIANG:
1. Nasi merah + ayam kukus + sayur bayam
2. Quinoa + ikan salmon + brokoli
3. Nasi merah + tahu tempe + capcay
```

## 🔧 Kustomisasi Rules

### Menambah Menu Baru
Edit file `rules.py` pada bagian `_initialize_menu_rules()`:

```python
'turun': {
    'sarapan': [
        'Menu existing...',
        'Menu baru Anda'  # Tambahkan di sini
    ]
}
```

### Mengubah Faktor Aktivitas
Edit file `diet_system.py` pada method `calculate_daily_calories()`:

```python
activity_multiplier = {
    'ringan': 1.2,    # Ubah nilai ini
    'normal': 1.35,   # Ubah nilai ini
    'berat': 1.5      # Ubah nilai ini
}
```

### Mengubah Defisit/Surplus Kalori
Edit file `diet_system.py` pada method `determine_target_calories()`:

```python
if goal == 'turun':
    self.target_calories = self.daily_calories - 300  # Ubah 300
elif goal == 'naik':
    self.target_calories = self.daily_calories + 300  # Ubah 300
```

## 🎯 Kesimpulan

Sistem ini berhasil mengimplementasikan Rule-Based System untuk rekomendasi diet dengan:
- ✅ Perhitungan BMR yang akurat
- ✅ Rules yang jelas dan dapat dijelaskan
- ✅ Interface yang user-friendly
- ✅ Output yang informatif dan actionable
- ✅ Struktur code yang modular dan mudah dikembangkan

Sistem dapat dikembangkan lebih lanjut dengan menambah rules baru, menu yang lebih variatif, atau integrasi dengan database nutrisi yang lebih lengkap.