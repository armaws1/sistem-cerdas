"""
Utility Functions untuk Sistem Diet
Berisi fungsi-fungsi pembantu untuk input, output, dan validasi
"""

def get_user_input():
    """
    Mengambil input dari pengguna dengan validasi
    
    Returns:
        tuple: (age, weight, height, activity_level, diet_goal)
    """
    print("=" * 60)
    print("🍎 SISTEM CERDAS REKOMENDASI MENU DIET 🍎")
    print("=" * 60)
    print()
    
    # Input umur
    while True:
        try:
            age = int(input("Masukkan umur Anda (tahun): "))
            if 10 <= age <= 100:
                break
            else:
                print("❌ Umur harus antara 10-100 tahun!")
        except ValueError:
            print("❌ Masukkan angka yang valid!")
    
    # Input berat badan
    while True:
        try:
            weight = float(input("Masukkan berat badan Anda (kg): "))
            if 30 <= weight <= 200:
                break
            else:
                print("❌ Berat badan harus antara 30-200 kg!")
        except ValueError:
            print("❌ Masukkan angka yang valid!")
    
    # Input tinggi badan
    while True:
        try:
            height = float(input("Masukkan tinggi badan Anda (cm): "))
            if 100 <= height <= 250:
                break
            else:
                print("❌ Tinggi badan harus antara 100-250 cm!")
        except ValueError:
            print("❌ Masukkan angka yang valid!")
    
    # Input tingkat aktivitas
    print("\nPilih tingkat aktivitas Anda:")
    print("1. Ringan (jarang olahraga)")
    print("2. Normal (olahraga 1-3x seminggu)")
    print("3. Berat (olahraga 4-7x seminggu)")
    
    while True:
        try:
            activity_choice = int(input("Pilihan Anda (1/2/3): "))
            if activity_choice == 1:
                activity_level = "ringan"
                break
            elif activity_choice == 2:
                activity_level = "normal"
                break
            elif activity_choice == 3:
                activity_level = "berat"
                break
            else:
                print("❌ Pilih 1, 2, atau 3!")
        except ValueError:
            print("❌ Masukkan angka yang valid!")
    
    # Input tujuan diet
    print("\nPilih tujuan diet Anda:")
    print("1. Turun berat badan")
    print("2. Menjaga berat badan (stabil)")
    print("3. Naik berat badan")
    
    while True:
        try:
            goal_choice = int(input("Pilihan Anda (1/2/3): "))
            if goal_choice == 1:
                diet_goal = "turun"
                break
            elif goal_choice == 2:
                diet_goal = "stabil"
                break
            elif goal_choice == 3:
                diet_goal = "naik"
                break
            else:
                print("❌ Pilih 1, 2, atau 3!")
        except ValueError:
            print("❌ Masukkan angka yang valid!")
    
    return age, weight, height, activity_level, diet_goal

def display_results(results):
    """
    Menampilkan hasil rekomendasi diet dalam format yang rapi
    
    Args:
        results (dict): Hasil dari rule-based system
    """
    profile = results['user_profile']
    menu = results['menu_recommendation']
    
    print("\n" + "=" * 60)
    print("📊 HASIL ANALISIS PROFIL ANDA")
    print("=" * 60)
    
    # Tampilkan profil pengguna
    print(f"👤 Umur: {profile['user_data']['age']} tahun")
    print(f"⚖️  Berat Badan: {profile['user_data']['weight']} kg")
    print(f"📏 Tinggi Badan: {profile['user_data']['height']} cm")
    print(f"🏃 Aktivitas: {profile['user_data']['activity_level'].title()}")
    print(f"🎯 Tujuan: {profile['user_data']['diet_goal'].title()} Berat Badan")
    
    print("\n" + "=" * 60)
    print("🔥 HASIL PERHITUNGAN KALORI")
    print("=" * 60)
    
    print(f"📈 BMR (Metabolisme Basal): {profile['bmr']} kalori/hari")
    print(f"⚡ Kebutuhan Kalori Harian: {profile['daily_calories']} kalori/hari")
    print(f"🎯 Target Kalori: {profile['target_calories']} kalori/hari")
    print(f"📋 Kategori Diet: {profile['diet_category']}")
    
    print("\n" + "=" * 60)
    print("🍽️  REKOMENDASI MENU DIET ANDA")
    print("=" * 60)
    
    print(f"🎯 Fokus Diet: {results['diet_focus']}")
    print(f"💡 Tips: {results['diet_tips']}")
    
    print("\n🌅 SARAPAN:")
    for i, item in enumerate(menu['sarapan'], 1):
        print(f"   {i}. {item}")
    
    print("\n🌞 MAKAN SIANG:")
    for i, item in enumerate(menu['siang'], 1):
        print(f"   {i}. {item}")
    
    print("\n🌙 MAKAN MALAM:")
    for i, item in enumerate(menu['malam'], 1):
        print(f"   {i}. {item}")
    
    print("\n🍎 SNACK:")
    for i, item in enumerate(menu['snack'], 1):
        print(f"   {i}. {item}")
    
    print("\n" + "=" * 60)
    print("✅ REKOMENDASI BERHASIL DIBUAT!")
    print("💪 Semoga berhasil mencapai tujuan diet Anda!")
    print("=" * 60)

def calculate_bmi(weight, height):
    """
    Menghitung BMI (Body Mass Index)
    
    Args:
        weight (float): Berat badan dalam kg
        height (float): Tinggi badan dalam cm
        
    Returns:
        tuple: (bmi_value, bmi_category)
    """
    height_m = height / 100  # Convert cm to meter
    bmi = weight / (height_m ** 2)
    
    if bmi < 18.5:
        category = "Underweight"
    elif 18.5 <= bmi < 25:
        category = "Normal"
    elif 25 <= bmi < 30:
        category = "Overweight"
    else:
        category = "Obese"
    
    return round(bmi, 2), category

def save_results_to_file(results, filename="diet_result.txt"):
    """
    Menyimpan hasil rekomendasi ke file
    
    Args:
        results (dict): Hasil rekomendasi
        filename (str): Nama file output
    """
    profile = results['user_profile']
    menu = results['menu_recommendation']
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("SISTEM CERDAS REKOMENDASI MENU DIET\n")
        f.write("=" * 50 + "\n\n")
        
        f.write("PROFIL PENGGUNA:\n")
        f.write(f"Umur: {profile['user_data']['age']} tahun\n")
        f.write(f"Berat Badan: {profile['user_data']['weight']} kg\n")
        f.write(f"Tinggi Badan: {profile['user_data']['height']} cm\n")
        f.write(f"Aktivitas: {profile['user_data']['activity_level'].title()}\n")
        f.write(f"Tujuan: {profile['user_data']['diet_goal'].title()}\n\n")
        
        f.write("HASIL PERHITUNGAN:\n")
        f.write(f"BMR: {profile['bmr']} kalori/hari\n")
        f.write(f"Kebutuhan Kalori: {profile['daily_calories']} kalori/hari\n")
        f.write(f"Target Kalori: {profile['target_calories']} kalori/hari\n")
        f.write(f"Kategori: {profile['diet_category']}\n\n")
        
        f.write("REKOMENDASI MENU:\n")
        f.write(f"Fokus: {results['diet_focus']}\n")
        f.write(f"Tips: {results['diet_tips']}\n\n")
        
        f.write("SARAPAN:\n")
        for item in menu['sarapan']:
            f.write(f"- {item}\n")
        
        f.write("\nMAKAN SIANG:\n")
        for item in menu['siang']:
            f.write(f"- {item}\n")
        
        f.write("\nMAKAN MALAM:\n")
        for item in menu['malam']:
            f.write(f"- {item}\n")
        
        f.write("\nSNACK:\n")
        for item in menu['snack']:
            f.write(f"- {item}\n")
    
    print(f"\n💾 Hasil telah disimpan ke file: {filename}")

def validate_input_range(value, min_val, max_val, value_name):
    """
    Validasi input dalam rentang tertentu
    
    Args:
        value: Nilai yang akan divalidasi
        min_val: Nilai minimum
        max_val: Nilai maximum
        value_name: Nama nilai untuk pesan error
        
    Returns:
        bool: True jika valid, False jika tidak
    """
    if min_val <= value <= max_val:
        return True
    else:
        print(f"❌ {value_name} harus antara {min_val}-{max_val}!")
        return False